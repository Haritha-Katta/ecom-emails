import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Directive({
  selector: '[safeInnerHTML]'
})
export class SafeInnerHTMLDirective {
  private _html: string = '';

  constructor(private el: ElementRef, private renderer: Renderer2, private sanitizer: DomSanitizer) {}

  @Input('safeInnerHTML')
  set safeHTML(html: string) {
    this._html = html;
    this.updateHTML();
  }

  private updateHTML() {
    const sanitizedHtml: SafeHtml = this.sanitizer.bypassSecurityTrustHtml(this._html);
    this.renderer.setProperty(this.el.nativeElement, 'innerHTML', sanitizedHtml);
  }
}
