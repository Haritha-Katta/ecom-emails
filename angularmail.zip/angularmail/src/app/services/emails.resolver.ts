import { Injectable } from '@angular/core';
import {
  Router, Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot,
  ActivatedRoute 
} from '@angular/router';
import { Observable, of, pluck, tap } from 'rxjs';
import { Email } from '../models/email';
import { EmailService } from './email.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FilterBy } from '../models/filterBy';
import { LoadEmails, RemoveEmails } from '../store/actions/email.actions';
import { State, Store } from '@ngrx/store';


export const EMAIL_KEY = 'email'

@Injectable({
  providedIn: 'root'
})
export class EmailsResolver implements Resolve<Email> {
  private apiUrl = 'http://localhost:8080/api/gmail/user/{username}/emails'; 
  private cacheExpirationTime = 1000 * 60 * 60; 
  emails!: any
  filterBy$!: Observable<FilterBy>

  constructor( private router:Router, private http: HttpClient, private emailService: EmailService, private store: Store<State<any>>, private route: ActivatedRoute) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
    console.log("Inside emails resolver");

    const queryParams = route.queryParams;

    //const username = route.paramMap.get('username');
    const username = queryParams['username'] ? queryParams['username'] : 'harithak';
    console.log("username: ",username);
    if (!username) {
      console.error('Username not found in route');
      return of([]); 
    }

    const currentUsername = localStorage.getItem('currentUsername');
    console.log("currentUsername: ",currentUsername);

    if (currentUsername !== username) {
      console.log('Username has changed, clearing cache');
      localStorage.removeItem('currentUsername');
      localStorage.removeItem(EMAIL_KEY);  // Remove cached emails
      localStorage.setItem('currentUsername', username); // Save the new username
    }

    // Check if emails are already cached in localStorage
    const cachedEmails = localStorage.getItem(EMAIL_KEY);
    const cacheTimestamp = localStorage.getItem(`${EMAIL_KEY}_timestamp`);

    if (cachedEmails && cacheTimestamp) {
      const currentTime = new Date().getTime();
      const cacheAge = currentTime - parseInt(cacheTimestamp, 10);

      // Check if cache is expired
      if (cacheAge < this.cacheExpirationTime && currentUsername === username) {
        console.log('Using cached emails');
        // Return cached emails as an observable
        return of(JSON.parse(cachedEmails));
      } else {
        console.log('Cache expired or username mismatch, fetching new data');
        // Remove expired cache and fetch new data
        localStorage.removeItem(EMAIL_KEY);
        localStorage.removeItem(`${EMAIL_KEY}_timestamp`);
      }
    }

    // If no cached emails or cache is expired, make the API call
    const dynamicApiUrl = this.apiUrl.replace('{username}', username);

    return this.http.get(dynamicApiUrl).pipe(
      tap((data: any) => {
        console.log("Fetched emails data:", data);

        // Create emails using the email service
        this.emails = this.emailService.createEmails(data);

        // Cache the emails in localStorage
        localStorage.setItem(EMAIL_KEY, JSON.stringify(this.emails));

        // Store the timestamp of when the emails were cached
        localStorage.setItem(`${EMAIL_KEY}_timestamp`, new Date().getTime().toString());

        // Dispatch the loaded emails to the store
        this.store.dispatch(new LoadEmails());
      })
    );
  }
}