import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Client, Stomp } from '@stomp/stompjs'; // Import the Client class directly
import * as SockJS from 'sockjs-client';
import { Email } from '../models/email';
import { Store } from '@ngrx/store';
import { State } from 'src/app/store/store'
import { SaveEmail } from '../store/actions/email.actions';
import { DatePipe } from '@angular/common';
import { EmailService } from './email.service';

@Injectable({
  providedIn: 'root',
})
export class WebSocketService {
  private stompClient!: Client;
  private messageSubject: Subject<any> = new Subject<any>();
  from: any;
  to: any;
  savedAt: any;
  subject: any;
  email!: Email

  loggedinUser = {
    email: 'farmersinsurance@gmail.com',
    fullname: 'Farmers Insurance'
  }

  constructor(private store: Store<State>, private emailService: EmailService) {

    const socket = new WebSocket('ws://localhost:8080/ws');
    const stompClient = Stomp.over(socket);
    console.log("stompClient:", stompClient);
    stompClient.connect({}, (frame: any) => {
      console.log('Connected: ' + frame);
      stompClient.subscribe('/topic/updates/harithak@claimsitdev.farmers.com', (messageOutput) => {
        console.log("inside topic received")
        console.log(messageOutput.body);
        this.createEmail(messageOutput.body);
      });
    }, function (error: any) {
      console.error('Error: ' + error);
    });
  }

  createEmail(data: any): void {
    data = JSON.parse(data);
    console.log("data: ",data);
    console.log("rec data: ", data.payload);
      const currentMessage = data;
       console.log("currentMessage: ",currentMessage);
      console.log("currentMessage payload: ",currentMessage.payload);
      // const isIncoming = currentMessage.labelIds.includes("INBOX") ? true : false
      const isIncoming = true;
       const name = ''
       const body = currentMessage.payload.body.data;
       
       for(let i = 0; i < currentMessage.payload.headers.length; i++) {
           console.log("currentMessage.payload.headers[i].name: ",currentMessage.payload.headers[i].name);
           console.log("currentMessage.payload.headers[i].value: ",currentMessage.payload.headers[i].value)
           if(currentMessage.payload.headers[i].name == "From") {
               this.from = currentMessage.payload.headers[i].value;
           } else if(currentMessage.payload.headers[i].name == "To") {
               this.to = currentMessage.payload.headers[i].value;
           } else if(currentMessage.payload.headers[i].name == "Date") {
               this.savedAt = currentMessage.payload.headers[i].value;
           } else if(currentMessage.payload.headers[i].name == "Subject") {
               this.subject = currentMessage.payload.headers[i].value;
           }                
       }
       const newMessage1 = [];
       newMessage1.push(currentMessage);
       console.log("newMessage1: ",newMessage1);
       currentMessage.labelIds = currentMessage.labelIds.map((str:any) => str.toLowerCase());
       currentMessage.labelIds = currentMessage.labelIds.map((str:any) => str.replace('draft', 'drafts'));
      /* this.email = {
           _id: currentMessage.threadId,
           messages: newMessage1,
           tabs: ["inbox", "unread"],
           name: isIncoming ? name : this.loggedinUser.fullname,
           subject: this.subject,
           body,
           attachments: currentMessage.payload.attachments,
           isRead:  currentMessage.labelIds.some((label: string) => label.toLowerCase() === 'unread') ? false : true, 
           savedAt: this.savedAt,
           from: this.from,
           to: this.to,
           labels: []
       }
       console.log("Generated email: ",this.email)*/

   console.log("current emailAddress ",sessionStorage.getItem('emailAddress'));
   console.log("currentMessage.labelIds: ",currentMessage.labelIds);

   const isRead = currentMessage.labelIds.includes('unread') ? false : true;
    console.log("isRead: ",isRead);
    console.log("sessionStorage.getItem('emailAddress'): ",sessionStorage.getItem('emailAddress'));
    console.log("this.to: ",this.to);
    const str = "Haritha Katta <harithak@claimsitdev.farmers.com>";
    const regex = /<([^>]+)>/;  // Regex to match the email inside <>
    const match = str.match(regex);

    if (match) {
      this.to = match[1];
    } 
    console.log("this.to: ",this.to);
   if(sessionStorage.getItem('emailAddress') == this.to) {
   let datePipe = new DatePipe("en-US");
   this.email = {
      "threadId": currentMessage.threadId,
      "snippet": currentMessage.snippet,
      "isRead":  isRead, 
      "subject": this.subject,
      "to": this.to,
      "body": currentMessage.payload.body.data,
      "messages" : newMessage1,
      "from": this.from,
      "name": sessionStorage.getItem('emailAddress')?.split('@')[0],
      "savedAt": this.emailService.convertSavedAtToUserTimeZone(this.savedAt) ,
      "labels": []
    };

    console.log("ws this.email: ",this.email);

    this.store.dispatch(new SaveEmail(
      {
        ...this.email,
        tabs: ['inbox', 'unread', 'unread']
      }
    ))

  } else {
    console.log("Email sent to other mail box");
  }
  }

  sendMessage(destination: string, message: any): void {
    if (this.stompClient.connected) {
      this.stompClient.publish({
        destination: destination,
        body: JSON.stringify(message),
      });
    }
  }

  getMessages() {
    return this.messageSubject.asObservable();
  }
}
