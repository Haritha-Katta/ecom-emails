import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, from, filter } from 'rxjs';
import { Email } from '../models/email';
import { LoadingEmails, UpdateEmails } from '../store/actions/email.actions';
import { EmailState } from '../store/reducers/email.reducer';
import { UtilService } from './util.service';

// import * as demoMails from '../../assets/data/demoMails.json' 

import { storageService } from './async-storage.service'
import { FilterBy } from '../models/filterBy';
import { Label } from '../models/label';
import * as moment from 'moment-timezone';

export const EMAIL_KEY = 'email'
export const LABEL_KEY = 'label'

@Injectable({
    providedIn: 'root',
})
export class EmailService {

    savedAt: any;
    from: any;
    to: any;
    subject: any;

    loggedinUser = {
        email: 'farmersinsurance@gmail.com',
        fullname: 'Farmers Insurance'
    }
    emails!: any
    private apiUrl = 'http://localhost:8080/api/gmail/emails?continue';

    constructor(private store: Store<EmailState>,
        private http: HttpClient,
        private utilService: UtilService) {

        /*const emails = JSON.parse(localStorage.getItem(EMAIL_KEY) || 'null');
        if (!emails || emails.length === 0) {
            localStorage.setItem(EMAIL_KEY, JSON.stringify(this._createEmails()))
        }*/

        const labels = JSON.parse(localStorage.getItem(LABEL_KEY) || 'null');
        if (!labels || labels.length === 0) {
            localStorage.setItem(LABEL_KEY, '[]')
        }

    }

    setEmailData(data: any) {
        this.emails = data;
    }

    getEmailData() {
        return this.emails;
    }

    getEmails() {
        this.http.get(this.apiUrl).subscribe((data) => {
            console.log("emails data: ", data);
            this.setEmailData(data);
        });
    }

    query(filterBy: FilterBy = {}): Observable<{ entities: Email[], totalPages: number }> {
        this.store.dispatch(new LoadingEmails());
        // console.log('EmailService: Return Emails ===> effect');
        return from(storageService.query(EMAIL_KEY, filterBy) as Promise<{ entities: Email[], totalPages: number }>)
        // return new Observable((observer) => observer.next(emails));
    }

    getById(emailId: string): Observable<Email> {
        // console.log('EmailService: Return Email ===> effect');
        return from(storageService.get(EMAIL_KEY, emailId) as Promise<Email>)
        // return from(axios.get(URL + emailId) as Promise<Email>)
    }

    remove(emailId: string): Observable<boolean> {
        // console.log('EmailService: Removing Email ===> effect');
        return from(storageService.remove(EMAIL_KEY, emailId))
    }

    removeMany(emails: Email[]): Observable<Email[]> {
        // console.log('EmailService: Removing Emails ===> effect');
        return from(storageService.removeMany(EMAIL_KEY, emails) as Promise<Email[]>)
    }


    save(email: Email): Observable<Email> {
        const method = (email._id) ? 'put' : 'post'
        // console.log('SERVICE:', method, 'email:', email)
        if (!email._id) email = {
            ...email,
            from: email.from ? email.from : this.loggedinUser.email,
            name: email.name ? email.name : this.loggedinUser.fullname,
            isRead: email.isRead,
            labels: [],
        }
        console.log("inside email service after change: ",email);
        const prmSavedEmail = storageService[method](EMAIL_KEY, email)
        // console.log('EmailService: Saving Email ===> effect');
        return from(prmSavedEmail) as Observable<Email>
    }

    updateMany(emails: Email[]): Observable<Email[]> {
        // console.log('EmailService: updated Emails ===> effect');
        return from(storageService.putMany(EMAIL_KEY, emails) as Promise<Email[]>)
    }

    /* public createEmails(emailData: any): Email[] {
 
         console.log("createEmails emailData: ",emailData);
 
         let emails = []
         for (var i = 0; i < 80; i++) {
             emails.push(this._createEmail())
         }
         return emails
     }
     private _createEmail(): Email {
         const isIncoming = Math.random() > .5 ? true : false
         const name = this.utilService.makeName()
         const {subject,body} = this.utilService.generateEmailContent()
         const email = {
             _id: this.utilService.makeId(),
             tabs: isIncoming ? [Math.random() > .5 ? 'starred' : 'important', Math.random() > .3 ? 'inbox' : 'spam'] : [Math.random() > .5 ? 'important' : 'starred', 'sent'],
             name: isIncoming ? name : this.loggedinUser.fullname,
             subject,
             body,
             isRead: (Math.random() > .5 && isIncoming) ? false : true,
             savedAt: this.utilService.randomTimestamp(),
             from: isIncoming ? `${name.split(' ')[0].toLowerCase()}@gmail.com` : this.loggedinUser.email,
             to: isIncoming ? this.loggedinUser.email : `${name.split(' ')[0].toLowerCase()}@gmail.com`,
             labels: []
         }
         return email
     } */

    public createEmails(emailData: any): Email[] {

        console.log("emailData: ", emailData.threads)
        let emails = []
        for (let i = 0; i < emailData.threads.length; i++) {
            emails.push(this._createEmail(emailData.threads[i]))
        }
        console.log("emails in create eails functio n: ", emails)
        return emails
    }
    private _createEmail(currentEmail: any): Email {
        console.log("currentEmail: ", currentEmail);
        console.log("current message: ", currentEmail.messages[currentEmail.messages.length - 1])
        const currentMessage = currentEmail.messages[currentEmail.messages.length - 1];
        console.log("currentMessages.length: ", currentEmail.messages.length);
        console.log("currentMessages: ", currentMessage);
        const isIncoming = currentMessage.labelIds.includes("INBOX") ? true : false
        const name = this.utilService.makeName()
        const body = '';
        if (currentMessage.payload.body) {
            const body = currentMessage.payload.body.data;
        }

        for (let i = 0; i < currentMessage.payload.headers.length; i++) {
            console.log("currentMessage.payload.headers[i].name: ", currentMessage.payload.headers[i].name);
            console.log("currentMessage.payload.headers[i].value: ", currentMessage.payload.headers[i].value)
            if (currentMessage.payload.headers[i].name == "From") {
                this.from = currentMessage.payload.headers[i].value;
            } else if (currentMessage.payload.headers[i].name == "To") {
                this.to = currentMessage.payload.headers[i].value;
            } else if (currentMessage.payload.headers[i].name == "Date") {
                this.savedAt = currentMessage.payload.headers[i].value;
            } else if (currentMessage.payload.headers[i].name == "Subject") {
                this.subject = currentMessage.payload.headers[i].value;
            }
        }

        console.log("savedddddddddd" + this.savedAt)
        currentMessage.labelIds = currentMessage.labelIds.map((str: any) => str.toLowerCase());
        currentMessage.labelIds = currentMessage.labelIds.map((str: any) => str.replace('draft', 'drafts'));
        const email = {
            _id: currentEmail.id,
            messages: currentEmail.messages,
            tabs: currentMessage.labelIds,
            name: this.from.split('@')[0] ? this.from.split('@')[0] : this.from.split('@')[0] ,
            subject: this.subject,
            body,
            attachments: currentMessage.payload.attachments,
            isRead: currentMessage.labelIds.some((label: string) => label.toLowerCase() === 'unread') ? false : true,
            savedAt: this.convertSavedAtToUserTimeZone(this.savedAt),
            from: this.from,
            to: this.to,
            labels: []
        }
        console.log("email in create email: ", email)
        return email
    }



    // LABEL FUNCTIONS:
    getLabels() {
        return from(storageService.query(LABEL_KEY) as Promise<{ entities: Label[], totalPages: number }>)
        // return new Observable((observer) => observer.next(emails));
    }

    saveLabel(label: Label): Observable<Label> {
        const method = (label._id) ? 'putLabel' : 'postLabel'
        const prmSavedLabel = storageService[method](LABEL_KEY, label)
        // console.log('EmailService: Saving Email ===> effect');
        return from(prmSavedLabel) as Observable<Label>
    }

    removeLabel(labelId: string): Observable<boolean> {
        // console.log('EmailService: Removing Email ===> effect');
        return from(storageService.remove(LABEL_KEY, labelId))
    }
    sendEmail(emailData: any): Observable<any> {
        //  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

        return this.http.post("http://localhost:8080/send-email", emailData);
    }

    getEmailTable(): Observable<any> {
        return this.http.get("http://localhost:8080/get-all-emails");
    }


    public convertSavedAtToUserTimeZone(savedAt: string): any {
        const savedAtMoment = moment(savedAt);
        const utcMoment = savedAtMoment.utc();
        console.log("UTC Time: ", utcMoment.format('YYYY-MM-DD HH:mm:ss Z'));
        const userTimeZone = moment.tz.guess();
        console.log("User Time Zone: ", userTimeZone);
        const userTime = utcMoment.tz(userTimeZone);
        console.log("Converted to User Time Zone: ", userTime.format('ddd, DD MMM YYYY HH:mm:ss Z'));
        return userTime.format('ddd, DD MMM YYYY HH:mm:ss Z');
    }

}




