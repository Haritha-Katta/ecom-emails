import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, pluck, Subscription, take } from 'rxjs';
import { Email, selectedEmail } from 'src/app/models/email';
import { State } from '../../store/store';
import { LoadEmails, RemoveEmails, SetFolder, UPDATED_EMAILS, UpdateEmails } from 'src/app/store/actions/email.actions';
import { FilterBy } from 'src/app/models/filterBy';
import { Actions, ofType } from '@ngrx/effects';
import { Label } from 'src/app/models/label';
import { EMAIL_KEY, EmailService } from 'src/app/services/email.service';
import { SaveEmail } from '../../store/actions/email.actions'
import { DatePipe } from '@angular/common';

@Component({
  selector: 'email-list',
  templateUrl: './email-list.component.html',
  styleUrls: ['./email-list.component.scss']
})
export class EmailListComponent {
  emails$: Observable<any>;
  filterBy$: Observable<FilterBy>;
  totalPages$: Observable<number>;
  labels$: Observable<Label[]>
  folder$: Observable<string>
  isLoading$: Observable<boolean>
  emails: any;

  from: any;
  to: any;
  savedAt: any;
  subject: any;
  email!: Email


  selectedEmails: Array<Email> = []
  tab: string = ''
  label: string = ''
  subscription!: Subscription


  constructor(private store: Store<State>,
    private actions$: Actions,
    private router: Router,
    private route: ActivatedRoute,
    private emailService: EmailService) {

    this.store.dispatch(new LoadEmails());
    this.emails$ = this.store.select('emailState').pipe(pluck('emails'));
    this.filterBy$ = this.store.select('emailState').pipe(pluck('filterBy'));
    this.totalPages$ = this.store.select('emailState').pipe(pluck('totalPages'));
    this.labels$ = this.store.select('emailState').pipe(pluck('labels'));
    this.folder$ = this.store.select('emailState').pipe(pluck('folder'));
    this.isLoading$ = this.store.select('emailState').pipe(pluck('isLoading'));
  }

  ngOnInit() {
    const { snapshot } = this.route
    this.subscription = this.route.params.subscribe(params => {
      let stateFolder
      this.folder$.pipe(take(1)).subscribe(folder => stateFolder = folder)
      this.tab = params['tab'] || ''
      this.label = params['labelName'] || ''
      /*this.route.data.subscribe((resolvedData) => {
        this.emails = resolvedData['data'];
        console.log("this.emails: ",this.emails)
      });*/

    /*  console.log("stateFolder: ",stateFolder);
      console.log("params['tab']: ",params['tab']);
      console.log("params['labelName']: ",params['labelName'])*/


      if (stateFolder === (params['tab'] || params['labelName']))
        this.filterBy$.pipe(take(1)).subscribe(filterBy => {
      console.log("before loading emails tab: ",filterBy)
          this.store.dispatch(new LoadEmails(filterBy))
        })
      else {
        if (params['tab']) {
          this.store.dispatch(new SetFolder(this.tab))
          console.log("before loading emails txt")
          this.store.dispatch(new LoadEmails({ txt: '', page: 0, tab: this.tab, pageSize: 25 }))
        }
        else if (params['labelName']) {
          this.store.dispatch(new SetFolder(this.label))
          console.log("before loading emails label")
          this.loadByLabel()
        }
      }
    })
  }

  toggleCheckbox(payload: selectedEmail): void {
    if (payload.checked) {
      this.selectedEmails.push(payload.email)
    }
    else {
      const idx = this.selectedEmails.findIndex(e => e._id === payload.email._id)
      this.selectedEmails.splice(idx, 1)
    }
  }

  toggleTab(updated: Email): void {
    this.store.dispatch(new UpdateEmails([updated]))
    this.actions$.pipe(ofType(UPDATED_EMAILS)).subscribe(() => {

      this.filterBy$.pipe(take(1)).subscribe(filterBy => {
        this.store.dispatch(new LoadEmails({ ...filterBy }))
      })
    })
  }

  onRemoveEmails() {
    const emails: Email[] = JSON.parse(JSON.stringify(this.selectedEmails))
    //  when remove from collection
    if (this.tab === 'trash' || this.tab === 'spam') {
      this.store.dispatch(new RemoveEmails(emails))
    }
    // when change all to trash tab
    else {
      emails.forEach(email => {
        let newTabs: string[] = email.tabs!.filter((tab, idx) => {
          return !(tab === 'inbox' || tab === 'sent')
        })
        newTabs.push('trash')
        email.tabs = newTabs
      })

      this.store.dispatch(new UpdateEmails(emails))
      this.actions$.pipe(ofType(UPDATED_EMAILS)).subscribe(() => {

        this.filterBy$.pipe(take(1)).subscribe(filterBy => {
          this.store.dispatch(new LoadEmails({ ...filterBy }))
        })
      })
    }

    this.selectedEmails = []
  }

  setPage(diff: number) {
    this.filterBy$.pipe(take(1)).subscribe(filterBy => {
      const { page } = filterBy
      this.store.dispatch(new LoadEmails({ ...filterBy, page: page! + diff }))
    })
  }

  onSetReadStat() {
    const emails: Email[] = JSON.parse(JSON.stringify(this.selectedEmails))
    // if all were read
    if (emails.some(email => !email.isRead)) {
      emails.forEach(e => e.isRead = true)
    } else {
      emails.forEach(e => e.isRead = false)
    }

    this.store.dispatch(new UpdateEmails(emails))
    this.actions$.pipe(ofType(UPDATED_EMAILS)).subscribe(() => {
      this.selectedEmails = []
    })
  }

  onSetTab(tab: string) {
    const emails: Email[] = JSON.parse(JSON.stringify(this.selectedEmails))
    // when some email is already with the selected tab
    if (emails.some(e => e.tabs?.includes(tab))) {
      emails.forEach(e => {
        const idx: number = e.tabs!.findIndex(t => t === tab)
        if (idx !== -1) e.tabs!.splice(idx, 1)
      })

    } else {
      emails.forEach(e => e.tabs?.push(tab))
    }

    this.store.dispatch(new UpdateEmails(emails))
    this.actions$.pipe(ofType(UPDATED_EMAILS)).subscribe(() => {
      this.selectedEmails = []
    })
  }




  loadByLabel(): void {
    this.labels$.pipe(take(1)).subscribe(labels => {
      const labelId = labels.find(label => label.name === this.label)?._id || ''
      if (labelId)
        this.store.dispatch(new LoadEmails({ txt: '', page: 0, tab: labelId, pageSize: 10 }))
      else
        this.router.navigateByUrl('/email/inbox')
    })
  }

  looadEmail() {
    const recData = {"threadId":"194b65089cbee6ab","snippet":"sample mail 6","labelIds":["UNREAD","CATEGORY_PERSONAL","INBOX"],"payload":{"headers":[{"name":"From","value":"devadmin@claimsitdev.farmers.com"},{"name":"Date","value":"Thu, 30 Jan 2025 00:25:18 -0800"},{"name":"Subject","value":"sample mail 6"},{"name":"To","value":"utkarshs@claimsitdev.farmers.com"}],"body":{"data":"<h1>sample mail 6</h1></p><p></p>","mimeType":"multipart/alternative"}},"id":"194b65089cbee6ab"};
    console.log("recData: ",recData);
    this.createEmail(recData);
  }


  createEmail(data: any): void {
      //data = JSON.parse(data);
      console.log("data: ",data);
      console.log("rec data: ", data.payload);
        const currentMessage = data;
         console.log("currentMessage: ",currentMessage);
        console.log("currentMessage payload: ",currentMessage.payload);
        // const isIncoming = currentMessage.labelIds.includes("INBOX") ? true : false
        const isIncoming = true;
         const name = ''
         const body = currentMessage.payload.body.data;
         
         for(let i = 0; i < currentMessage.payload.headers.length; i++) {
             console.log("currentMessage.payload.headers[i].name: ",currentMessage.payload.headers[i].name);
             console.log("currentMessage.payload.headers[i].value: ",currentMessage.payload.headers[i].value)
             if(currentMessage.payload.headers[i].name == "From") {
                 this.from = currentMessage.payload.headers[i].value;
             } else if(currentMessage.payload.headers[i].name == "To") {
                 this.to = currentMessage.payload.headers[i].value;
             } else if(currentMessage.payload.headers[i].name == "Date") {
                 this.savedAt = currentMessage.payload.headers[i].value;
             } else if(currentMessage.payload.headers[i].name == "Subject") {
                 this.subject = currentMessage.payload.headers[i].value;
             }                
         }
         const newMessage1 = [];
         newMessage1.push(currentMessage);
         console.log("newMessage1: ",newMessage1);
         currentMessage.labelIds = currentMessage.labelIds.map((str:any) => str.toLowerCase());
         currentMessage.labelIds = currentMessage.labelIds.map((str:any) => str.replace('draft', 'drafts'));
        /* this.email = {
             _id: currentMessage.threadId,
             messages: newMessage1,
             tabs: ["inbox", "unread"],
             name: isIncoming ? name : this.loggedinUser.fullname,
             subject: this.subject,
             body,
             attachments: currentMessage.payload.attachments,
             isRead:  currentMessage.labelIds.some((label: string) => label.toLowerCase() === 'unread') ? false : true, 
             savedAt: this.savedAt,
             from: this.from,
             to: this.to,
             labels: []
         }
         console.log("Generated email: ",this.email)*/
  
     console.log("current emailAddress ",sessionStorage.getItem('emailAddress'));
     console.log("currentMessage.labelIds: ",currentMessage.labelIds);
  
     const isRead = currentMessage.labelIds.includes('unread') ? false : true;
      console.log("isRead: ",isRead);
  
     let datePipe = new DatePipe("en-US");
     this.email = {
        "threadId": currentMessage.threadId,
        "snippet": currentMessage.snippet,
        "isRead":  isRead, 
        "subject": this.subject,
        "to": this.to,
        "body": currentMessage.payload.body.data,
        "messages" : newMessage1,
        "from": this.from,
        "name": sessionStorage.getItem('emailAddress')?.split('@')[0],
        "savedAt": "Fri, 31 Jan 2025 11:58:29 +0530" ,
        "labels": []
      };
  
      console.log("ws this.email: ",this.email);
  
      this.store.dispatch(new SaveEmail(
        {
          ...this.email,
          tabs: ['inbox', 'unread', 'unread']
        }
      ))

    }

}



