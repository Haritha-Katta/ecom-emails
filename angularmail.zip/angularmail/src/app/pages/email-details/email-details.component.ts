import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Actions, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { Observable, pluck, take } from 'rxjs';
import { Email } from 'src/app/models/email';
import { Label } from 'src/app/models/label';
import { SaveLabel, UPDATED_EMAILS, UpdateEmails } from 'src/app/store/actions/email.actions';
import { State } from 'src/app/store/store';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'email-details',
  templateUrl: './email-details.component.html',
  styleUrls: ['./email-details.component.scss']
})
export class EmailDetailsComponent {
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private actions$: Actions,
    private location: Location,
    private store: Store<State>,
    private sanitizer: DomSanitizer) {
    this.labels$ = this.store.select('emailState').pipe(pluck('labels'));
  }
  email!: any
  isLabelMenu = false
  isLabelAdd = false
  labels$: Observable<Label[]>
  emailLabels!: Label[]
  showText: boolean = false;
  parsedContent: any;
  htmlContent: any;
  isViewerOpen: boolean = false;
  currentAttachmentUrl: any = '';
  isImageViewer: boolean = false;
  decodedBodyContent: any = ''; // To store decoded email body
  decodedPrevContent: any = ''; // To store previous message body
  testData = "Forward\r\n\r\n---------- Forwarded message ---------\r\nFrom: Google \u003Cno-reply@accounts.google.com\u003E\r\nDate: Fri, 17 Jan, 2025, 21:38\r\nSubject: Security alert\r\nTo: \u003Cdevadmin@claimsitdev.farmers.com\u003E\r\n\r\n\r\n[image: Google]\r\nA new sign-in on Galaxy S21 Ultra 5G\r\ndevadmin@claimsitdev.farmers.com\r\nWe noticed a new sign-in to your Google Account on a Galaxy S21 Ultra 5G\r\ndevice. If this was you, you don’t need to do anything. If not, we’ll help\r\nyou secure your account.\r\nCheck activity\r\n\u003Chttps://accounts.google.com/AccountChooser?Email=devadmin@claimsitdev.farmers.com&continue=https://myaccount.google.com/alert/nt/1737130093000?rfn%3D325%26rfnc%3D1%26eid%3D-7809587669885534130%26et%3D0\u003E\r\nYou can also see security activity at\r\nhttps://myaccount.google.com/notifications\r\nYou received this email to let you know about important changes to your\r\nGoogle Account and services.\r\n© 2025 Google LLC, 1600 Amphitheatre Parkway, Mountain View, CA 94043, USA\r\n";


  ngOnInit() {
    const { snapshot } = this.route;

    this.email = snapshot.data['email'];
    console.log("email before: ",this.email);

    if (this.email && this.email.messages) {
      // Decode the latest message
      const latestMessageBody = this.email.messages[this.email.messages.length - 1].payload.body.data;
      if (latestMessageBody) {
        this.decodedBodyContent = this.sanitizer.bypassSecurityTrustHtml(this.decodeBase64(latestMessageBody));
      }

      // Decode the previous messages (if any)
      this.email.messages.slice(0, -1).forEach((message: any) => {
        if (message.payload.body.data) {
          this.decodedPrevContent = this.sanitizer.bypassSecurityTrustHtml(this.decodeBase64(message.payload.body.data));
        }
      });

      console.log("email after decoding: ", this.email);
    }
    this.store.dispatch(new UpdateEmails([{ ...this.email, isRead: true }]))
    this.labels$.subscribe((labels) => {
      this.emailLabels = labels.filter(label => this.email.labels?.includes(label._id!))
    })

    
  }



  setEmailLabels() {
    this.labels$.pipe(take(1)).subscribe((labels) => {
      this.emailLabels = labels.filter(label => this.email.labels?.includes(label._id!))
    })
  }

  updateLabels(labels: string[] | null) {
    if (labels) {
      this.store.dispatch(new UpdateEmails([{ ...this.email, labels }]))
      this.actions$.pipe(ofType(UPDATED_EMAILS), take(1)).subscribe(() => {
        this.email = { ...this.email, labels }
        this.setEmailLabels()
      })
    }
    this.isLabelMenu = false
  }

  removeLabel(labelId: string) {
    console.log('removing:', labelId)
    const labels = this.email.labels!.filter((label: any) => label !== labelId)
    this.store.dispatch(new UpdateEmails([{ ...this.email, labels }]))
    this.actions$.pipe(ofType(UPDATED_EMAILS), take(1)).subscribe(() => {
      this.email = { ...this.email, labels }
      this.setEmailLabels()
    })


  }

  goBack() {
    this.location.back()
  }
  onSpam() {
    const tabs = [...this.email.tabs!]
    let idx = tabs.indexOf('inbox')
    if (idx === -1) idx = tabs.indexOf('sent')
    if (idx === -1) idx = tabs.indexOf('trash')
    tabs.splice(idx, 1, 'spam')
    const updatedEmail = { ...this.email, tabs }
    this.updateAndClose(updatedEmail)
  }
  onTrash() {
    const tabs = [...this.email.tabs!]
    tabs.push('trash')
    const updatedEmail = { ...this.email, tabs }
    this.updateAndClose(updatedEmail)
  }
  onUnread() {
    const updatedEmail = { ...this.email, isRead: !this.email.isRead }
    this.updateAndClose(updatedEmail)
  }
  updateAndClose(email: Email) {
    this.store.dispatch(new UpdateEmails([email]))
    this.actions$.pipe(ofType(UPDATED_EMAILS), take(1)).subscribe(() => {
      this.goBack()
    })
  }
  onToggleTab(tab: string) {
    const tabs = [...this.email.tabs!]
    const idx = tabs.indexOf(tab)
    idx === -1 ? tabs.push(tab) : tabs.splice(idx, 1)
    const email = { ...this.email, tabs }
    this.store.dispatch(new UpdateEmails([email]))
    this.actions$.pipe(ofType(UPDATED_EMAILS), take(1)).subscribe(() => {
      this.email.tabs = email.tabs
    })
  }

  compose(mode: string) {
    this.router.navigate(
      [],
      {
        relativeTo: this.route,
        queryParams: { compose: 'new', [mode]: this.email._id }
      })
  }

  saveLabel(label: Label) {
    this.isLabelAdd = false
    this.store.dispatch(new SaveLabel(label))
  }

  toggleText() {
    this.showText = !this.showText;
  }
  
  decodeBase64(base64Data: string): string {
    try {
      // Step 1: Fix padding (add `=` if necessary)
      let decodedBase64 = base64Data;
      const padding = decodedBase64.length % 4;
      if (padding > 0) {
        decodedBase64 += '='.repeat(4 - padding); // Add padding if required
      }

      // Step 2: Fix URL-safe Base64 characters (if present)
      decodedBase64 = decodedBase64.replace(/-/g, '+').replace(/_/g, '/');

      // Step 3: Decode the Base64 string
      const decodedData = atob(decodedBase64);

      // Step 4: Remove unwanted arrows (">") used in email reply chains
      let cleanedData = decodedData.replace(/^>+/gm, '').trim(); // Removes lines starting with ">" and extra spaces

      // Step 5: Replace newline characters with <br> for proper line breaks in HTML
      const formattedData = cleanedData.replace(/\n/g, '<br>');

      return formattedData;
    } catch (e) {
      console.error('Error decoding Base64:', e);
      return '';
    }
  }

  

  decodingBase64(base64Data: string): string {
    try {
      let decodedBase64 = decodeURIComponent(base64Data);
      const padding = decodedBase64.length % 4;
      if (padding > 0) {
        decodedBase64 += '='.repeat(4 - padding);
      }
      decodedBase64 = decodedBase64.replace(/-/g, '+').replace(/_/g, '/');
      const decodedData = atob(decodedBase64);
      const blob = new Blob([new Uint8Array(decodedData.split('').map(char => char.charCodeAt(0)))], { type: 'application/octet-stream' });
      const attachmentUrl = URL.createObjectURL(blob);
      return attachmentUrl; 
    } catch (e) {
      console.log(e);
      return ''; 
    }
  }

  viewAttachment(file: any) {
    const fileType = file.mimeType.split('/')[0];
      if (fileType === 'image' && file.data) {
        this.currentAttachmentUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.decodingBase64(file.data));
        this.isImageViewer = true;
        this.isViewerOpen = true;

      } else if (file.mimeType === 'application/pdf') {
        window.open(this.decodingBase64(file.data) as string, '_blank');
        this.isImageViewer = false;
        this.isViewerOpen = false;
      } else {
        const fileUrl = this.decodingBase64(file.data);
        const link = document.createElement('a');
        link.href = fileUrl;
        link.download = file.filename || 'download'; 
        link.click();
  
        this.isImageViewer = false;
    }
  }
  
  closeViewer() {
    this.isViewerOpen = false;
    this.isImageViewer = false;
  }
  getHeaderValue(headers: any[], headerName: string): string {
    const header = headers.find(h => h.name.toLowerCase() === headerName.toLowerCase());
    return header ? header.value : 'N/A'; // Return 'N/A' if header is not found
  }
}


