import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmailService } from 'src/app/services/email.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  show = false;
  email: any = [];
  username: string = '';
  loggedInEmail: any =  '';
  isLoading: boolean = false;

  constructor(private emailService: EmailService, private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.isLoading = true;

    this.route.queryParams.subscribe(params => {
      console.log("home query params: ", params); // Logs all the query parameters as an object
      this.router.navigate(['/email'], {
        queryParams: { username: params['username'] }
      });
    });
    this.emailService.getEmailTable().subscribe((data: any) => {
      this.email = data;
      this.isLoading = false;
    });
  }

  openEmailPage(email: string): void {
    this.isLoading = true;
    sessionStorage.setItem('emailAddress', email) ;
    this.username=email.split('@')[0];
      this.router.navigate([`/email/`, { username: this.username }]);
  }

}
