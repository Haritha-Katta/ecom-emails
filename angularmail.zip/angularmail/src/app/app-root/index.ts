import { ApplicationRef, Component, CUSTOM_ELEMENTS_SCHEMA, DoBootstrap, Injector } from '@angular/core';
import { Store } from '@ngrx/store';
import { map, Observable, pluck, tap, from } from 'rxjs';
import { FilterBy } from '../models/filterBy';
import { LoadEmails, LoadLabels } from '../store/actions/email.actions';
import { State } from '../store/store';
import { of, pipe } from 'rxjs';
import { filter } from 'rxjs/operators';
import { WebSocketService } from 'src/app/services/websocket.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  template: `
  <section class="app-root">
    <router-outlet></router-outlet>
  </section>
 `
})
export class AppComponent {

  title = 'Angular Email';
  private messageSubscription!: Subscription;
  messages: any[] = [];

  constructor(private store: Store<State>, private webSocketService: WebSocketService) { }

  ngOnInit() {
    this.store.dispatch(new LoadLabels());

    // Connect to WebSocket and listen to messages
    //this.webSocketService.connect();

    // Subscribe to incoming messages
    this.messageSubscription = this.webSocketService.getMessages().subscribe((message) => {
      this.messages.push(message);
    });
  }

  sendMessage(): void {
    // Send a test message via WebSocket
    const message = { text: 'Hello, WebSocket!' };
   // this.webSocketService.sendMessage('/app/send-message', message);
  }

  ngOnDestroy(): void {
    // Unsubscribe when component is destroyed
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
   // this.webSocketService.disconnect();
  }


}
