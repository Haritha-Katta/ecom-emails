
export interface Email{
  _id?:string,
  tabs?:Array<string>,
  name?:string,
  subject:string,
  body:string,
  isRead?:boolean,
  savedAt?:any,
  from?:string,
  to:string,
  labels?:Array<string>
  fromEmail?:string,
  toEmail?:string,
  bodyText?:string,
  attachment?:Attachment,
  messages?: any,
  attachments?: any,
  threadId?: any,
  snippet?: any,
  labelIds?: any,
  payload?: any,
  id?: any
}

export interface Attachment{
  attachmentBase64?:string, 
  attachmentFileName?:string
}

export interface selectedEmail{
  checked:boolean,
  email:Email
}


