// TODO: Add Price

export interface Item {
  id: string;
  txt: string;
}
