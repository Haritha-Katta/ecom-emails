// TODO: Add Price

export interface Label {
  _id?: string
  name: string
  clr?: string
}
