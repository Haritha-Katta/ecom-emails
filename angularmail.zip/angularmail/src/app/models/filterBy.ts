// TODO: Add Price

export interface FilterBy {
  txt?: string
  tab?: string
  page?: number
  pageSize?:number
  label?:string
}
