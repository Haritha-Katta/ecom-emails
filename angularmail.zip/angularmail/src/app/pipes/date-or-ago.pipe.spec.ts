import { DateOrAgoPipe } from './date-or-ago.pipe';

describe('DateOrAgoPipe', () => {
  it('create an instance', () => {
    const pipe = new DateOrAgoPipe();
    expect(pipe).toBeTruthy();
  });
});
