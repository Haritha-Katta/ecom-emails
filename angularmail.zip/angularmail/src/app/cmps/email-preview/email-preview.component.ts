import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Email, selectedEmail } from 'src/app/models/email';
import { EmailListComponent } from 'src/app/pages/email-list/email-list.component';

@Component({
  selector: 'email-preview',
  templateUrl: './email-preview.component.html',
  styleUrls: ['./email-preview.component.scss']
})
export class EmailPreviewComponent {
  @Input() email!: any;
  @Input() tab!: string;
  @Input() label!: string;
  lastMessage: any

  @Output() toggleCheckbox = new EventEmitter<selectedEmail>()
  @Output() toggleTab = new EventEmitter<Email>()
  link!: string
  params!: {}
  isChecked = false

  ngOnInit() {
    // console.log("in email preview: ",this.email);
    if (this.email.messages) {
      this.lastMessage = this.email.messages[this.email.messages.length - 1];
    } else {
      this.lastMessage = []
    }
    if (this.label) this.link = `/email/label/${this.label}/${this.email!._id}`
    else {
      this.link = this.tab === 'drafts' ? `/email/${this.tab}` : `/email/${this.tab}/${this.email!._id}`
      if (this.tab === 'drafts') this.params = { compose: this.email!._id }
    }
  }

  onToggleCheckbox(ev: Event) {
    const target = ev.target as HTMLInputElement
    const payload: selectedEmail = { checked: target.checked, email: this.email }
    this.toggleCheckbox.emit(payload)
    this.isChecked = target.checked
  }

  onToggleTab(ev: Event, tab: string) {
    ev.stopPropagation()
    var copyEmail: Email = JSON.parse(JSON.stringify(this.email))

    if (copyEmail.tabs?.includes(tab)) {
      const idx = copyEmail.tabs.findIndex(t => t === tab)
      copyEmail.tabs.splice(idx, 1)
    } else copyEmail.tabs?.push(tab)

    this.toggleTab.emit(copyEmail)
  }

  getNameFromEmail(email: any): string {
    // Split the email by '@' and take the first part
    if(email.includes(sessionStorage.getItem('emailAddress')))
      return "me";
    
    let name = email.split('@')[0];
    if(name.split(' ')[1]!==undefined)
    name = name.split(' ')[0] + " " + name.split(' ')[1];
   else
   name = name.split(' ')[0];
    // Optionally, format the name (e.g., capitalize first letter)
    name = name.replace(/[^a-zA-Z ]/g, "");  // Remove any non-alphabetic characters
    name = name.charAt(0).toUpperCase() + name.slice(1); // Capitalize the first letter
    return name;
  }

  isUnread: boolean = false;
  unread: any[] = [];


  getSenderNames(messages: any[]): any {
    const senders: { name: string, isUnread: any }[] = [];

    if (messages && messages.length > 1) {
      // Get first sender
      if (messages[0].labelIds.some((label: string) => label.toLowerCase() === 'unread')) {
        this.isUnread = true;
      }
      for (const m of messages[0].payload.headers) {
        if (m.name === 'From') {
          senders.push({ name: this.getNameFromEmail(m.value), isUnread: this.isUnread });
        }
      }

      if (messages.length > 2) {
        for (const m of messages[1].payload.headers) {
          if (messages[1].labelIds.some((label: string) => label.toLowerCase() === 'unread')) {
            this.isUnread = true;
          }
          if (m.name === 'From') {
            senders.push({ name: this.getNameFromEmail(m.value), isUnread: this.isUnread });
          }
        }
      }
      // Get last sender
      for (const m of messages[messages.length - 1].payload.headers) {
        if (messages[messages.length - 1].labelIds.some((label: string) => label.toLowerCase() === 'unread')) {
          this.isUnread = true;
        }
        if (m.name === 'From') {
          senders.push({ name: this.getNameFromEmail(m.value), isUnread: this.isUnread });
        }
      }
    }
    else {
      for (const m of messages[0].payload.headers) {
        if (messages[0].labelIds.some((label: string) => label.toLowerCase() === 'unread')) {
          this.isUnread = true;
        }
        if (m.name == 'From') {
          senders.push({ name: this.getNameFromEmail(m.value), isUnread: this.isUnread });
        }
      }
    }

    return senders; // Join senders with commas
  }


}

