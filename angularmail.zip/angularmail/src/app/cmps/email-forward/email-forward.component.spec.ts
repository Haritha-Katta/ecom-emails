import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailForwardComponent } from './email-forward.component';

describe('EmailForwardComponent', () => {
  let component: EmailForwardComponent;
  let fixture: ComponentFixture<EmailForwardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmailForwardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmailForwardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
