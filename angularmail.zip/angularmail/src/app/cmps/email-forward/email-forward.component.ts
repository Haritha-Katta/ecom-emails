import { Location } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Actions, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { Observable, pluck, take } from 'rxjs';
import { Email } from 'src/app/models/email';
import { Label } from 'src/app/models/label';
import { LOADED_EMAIL, SaveLabel, UPDATED_EMAILS, UpdateEmails } from 'src/app/store/actions/email.actions';
import { State } from 'src/app/store/store';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'email-forward',
  templateUrl: './email-forward.component.html',
  styleUrls: ['./email-forward.component.scss']
})
export class EmailForwardComponent implements OnChanges  {
   @Input() email!: any;
  
  constructor(
    private store: Store<State>,
    private sanitizer: DomSanitizer) {
  }
 
  showText: boolean = false;
  parsedContent: any;
  htmlContent: any;
  isViewerOpen: boolean = false;
  currentAttachmentUrl: any = '';
  isImageViewer: boolean = false;
  isMode=false;
  decodedBodyContent: string = ''; // To store decoded email body
  decodedPrevContent: string = ''; // To store previous message body

  ngOnChanges(changes: SimpleChanges): void { 
    if (this.email && this.email.messages&& Array.isArray(this.email.messages)) {
      // Decode the latest message
      const latestMessageBody = this.email.messages[this.email.messages.length - 1].payload.body.data;
      if (latestMessageBody) {
        this.decodedBodyContent = this.decodeBase64(latestMessageBody);
      }

      // Decode the previous messages (if any)
      this.email.messages.slice(0, -1).forEach((message: any) => {
        if (message.payload.body.data) {
          this.decodedPrevContent = this.decodeBase64(message.payload.body.data);
        }
      });
      console.log("email after decoding: ", this.email);
    }
 }
  ngOnInit() {

  }

  toggleText() {
    this.showText = !this.showText;
  }
  

  decodeBase64(base64Data: string): string {
    try {
      // Step 1: Fix padding (add `=` if necessary)
      let decodedBase64 = base64Data;
      const padding = decodedBase64.length % 4;
      if (padding > 0) {
        decodedBase64 += '='.repeat(4 - padding); // Add padding if required
      }

      // Step 2: Fix URL-safe Base64 characters (if present)
      decodedBase64 = decodedBase64.replace(/-/g, '+').replace(/_/g, '/');

      const decodedData = atob(decodedBase64);

      // Step 4: Remove unwanted arrows (">") used in email reply chains
      let cleanedData = decodedData.replace(/^>+/gm, '').trim(); // Removes lines starting with ">" and extra spaces

      // Step 5: Replace newline characters with <br> for proper line breaks in HTML
      const formattedData = cleanedData.replace(/\n/g, '<br>');

      return formattedData;
    } catch (e) {
      console.error('Error decoding Base64:', e);
      return '';
    }
  }

  

  decodingBase64(base64Data: string): string {
    try {
      let decodedBase64 = decodeURIComponent(base64Data);
      const padding = decodedBase64.length % 4;
      if (padding > 0) {
        decodedBase64 += '='.repeat(4 - padding);
      }
      decodedBase64 = decodedBase64.replace(/-/g, '+').replace(/_/g, '/');
      const decodedData = atob(decodedBase64);
      const blob = new Blob([new Uint8Array(decodedData.split('').map(char => char.charCodeAt(0)))], { type: 'application/octet-stream' });
      const attachmentUrl = URL.createObjectURL(blob);
      return attachmentUrl; 
    } catch (e) {
      console.log(e);
      return ''; 
    }
  }

  viewAttachment(file: any) {
    const fileType = file.mimeType.split('/')[0];
      if (fileType === 'image' && file.data) {
        this.currentAttachmentUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.decodingBase64(file.data));
        this.isImageViewer = true;
        this.isViewerOpen = true;

      } else if (file.mimeType === 'application/pdf') {
        window.open(this.decodingBase64(file.data) as string, '_blank');
        this.isImageViewer = false;
        this.isViewerOpen = false;
      } else {
        const fileUrl =this.sanitizer.bypassSecurityTrustResourceUrl( this.decodingBase64(file.data));
        const link = document.createElement('a');
        link.href = fileUrl as string;
        link.download = file.filename || 'download'; 
        link.click();
  
        this.isImageViewer = false;
    }
  }
  
  closeViewer() {
    this.isViewerOpen = false;
    this.isImageViewer = false;
  }
    
  getHeaderValue(headers: any[], headerName: string): string {
    const header = headers.find(h => h.name.toLowerCase() === headerName.toLowerCase());
    return header ? header.value : 'N/A'; // Return 'N/A' if header is not found
  }
}

