import { Component } from '@angular/core';

@Component({
  selector: 'email-filter',
  templateUrl: './email-filter.component.html',
  styleUrls: ['./email-filter.component.scss']
})
export class EmailFilterComponent {

}
