import { DatePipe } from '@angular/common'
import { ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core'
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { DomSanitizer } from '@angular/platform-browser'
import { ActivatedRoute, Router } from '@angular/router'
import { Actions, ofType } from '@ngrx/effects'
import { Store } from '@ngrx/store'
import { compareDesc } from 'date-fns'
import Quill from 'quill'
import { Observable, pluck, Subscription, take } from 'rxjs'
import { Email } from 'src/app/models/email'
import { FilterBy } from 'src/app/models/filterBy'
import { EmailService } from 'src/app/services/email.service'
import { EMAIL_KEY } from 'src/app/services/emails.resolver'
import { ADDED_EMAIL, LOADED_EMAIL, LoadEmail, LoadEmails, SaveEmail, UPDATED_EMAIL } from 'src/app/store/actions/email.actions'
import { State } from 'src/app/store/store'

@Component({
  selector: 'email-compose',
  templateUrl: './email-compose.component.html',
  styleUrls: ['./email-compose.component.scss']
})
export class EmailComposeComponent {

  constructor(private store: Store<State>,
    private actions$: Actions,
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private sanitizer: DomSanitizer,
    private emailsService: EmailService,) {
    this.email$ = this.store.select('emailState').pipe(pluck('email'))
    this.filterBy$ = this.store.select('emailState').pipe(pluck('filterBy'))
  }
supportingEmail!:any;
  email: Email = { to: '', subject: '', body: '' }
  subscription: Subscription | null = null;
  email$: Observable<Email | null>
  filterBy$: Observable<FilterBy>
  composeForm!: FormGroup
  isMini = false
  isFull = false
  title = 'New Message'
  draftInterval: number | null = null
  mode = ''
  attachments: File[] = [];
  emailInput: string = '';  // Current input in the field
  ccInput: string = '';
  emailSuggestions: any[] = [];
  activeField:any='';
  showPopup:boolean=false;
  recipients: string[] = [];  // List of selected recipients
  allEmails: any[] = [
    { firstname: 'Dev', lastname: 'Admin', email: 'devadmin@claimsitdev.farmers.com', alternate: '', terms: 'Opted In' },
    { firstname: 'Haritha', lastname: 'Katta', email: 'harithak@claimsitdev.farmers.com', alternate: '', terms: 'Opted In' },
    { firstname: 'Nalini', lastname: 'Nizamkar', email: 'nalinin@claimsitdev.farmers.com', alternate: 'gwj78g@gmail.com', terms: 'Opted Out' },
    { firstname: 'Shaji', lastname: 'Goerge', email: 'shajig@claimsitdev.farmers.com', alternate: '', terms: 'Opted In' },
    { firstname: 'Uthkarsh', lastname: 'Srivatsava', email: 'utkarshs@claimsitdev.farmers.com', alternate: '', terms: 'Opted Out' }
  ]
  
criticalLabel:string="[CRITICAL]";
claim:string="2000077007-1";
  cc: string[] = [];
  isTablePopupOpen: boolean = false;
  claims: any[] = [];
  isViewerOpen: boolean = false;
  currentAttachmentUrl: any = '';
  isPdfViewer: boolean = false;
  isImageViewer: boolean = false;
  quill:any;
  @ViewChild('editorContainer', { static: false }) editorContainer!: ElementRef;

  ngAfterViewInit() {
    this.quill = new Quill(this.editorContainer.nativeElement, {
      theme: 'snow', // Use 'snow' or another theme
      formats: ['font', 'size', 'bold', 'italic', 'underline', 'link', 'align', 'list'],
      modules: {
        toolbar: [
          [{ 'header': '1' }, { 'header': '2' }],
          //[{ 'font': ['arial', 'courier', 'georgia', 'monospace', 'helvetica', 'lucida-sans', 'tahoma', 'times-new-roman', 'trebuchet-ms', 'sans-serif'] }],
          [{'font': [] }],
          [{ 'size': [] }],
          [{ 'list': 'ordered' }, { 'list': 'bullet' }],
          ['bold', 'italic', 'underline'],
          [{ 'align': [] }],
          ['link']
        ]
      },
      placeholder: 'Compose email body',
    });

    if (this.email.body) {
      this.quill.root.innerHTML = this.email.body; // Set the initial value
    }
  
    // Update form control when the editor content changes
    this.quill.on('text-change', () => {
      const editorContent = this.quill.root.innerHTML;
      this.composeForm.controls['body'].setValue(editorContent); // Sync with form control
    });
  }

  ngOnInit() {
    this.buildForm()
    this.emailInput = this.composeForm.get('emailInput')?.value;
    this.ccInput = this.composeForm.get('ccInput')?.value;
    this.route.queryParams.subscribe(({ compose, re, fwd , all}) => {
      this.mode = re ? 're' : (fwd ? 'fwd' : (all ? 'all' : ''));

      if (re || fwd|| all) {
        this.store.dispatch(new LoadEmail(re || fwd ||all))
      }
      if (this.email._id !== compose) {
        if (compose === 'new') {
          this.email = { to: '', subject: '', body: '' }
          this.title = 'New Message'
          this.buildForm()
        }
        else this.store.dispatch(new LoadEmail(compose))
      }
    })
    this.actions$.pipe(ofType(LOADED_EMAIL)).subscribe(({ email }: any) => {
   
      if (this.mode) {
        const emailTo=email.to.split('<')[1]?email.to.split('<')[1].replace('>',''):email.to;
        this.recipients=[];
        this.email = email;
        if(this.mode==='re'){
          this.recipients.push(emailTo.split(',')?emailTo.split(',')[0]:emailTo);
          this.composeForm.controls['subject'].setValue("Re: "+email.subject);
        }

        else if(this.mode==='all'){
          this.composeForm.controls['subject'].setValue("Reply All: "+email.subject);
          this.recipients.push(emailTo.split(',')?emailTo.split(',')[0]:emailTo);
          this.email.messages.forEach((message: { payload: { headers: any[] } }) => {
            const toHeader = message.payload.headers.find(header => header.name === 'To'||header.name === 'From');
            if (toHeader) {
              toHeader.value.split(',').forEach((email: string) => {
                const trimmedEmail =email.split('<')[1]?email.split('<')[1].replace('>',''):email;  // Remove any leading/trailing spaces
                
                if (!this.recipients.includes(trimmedEmail)) {
                  this.recipients.push(trimmedEmail);
                }
              });
            }
          });
          
        }
        //this.email = this.buildRefEmail(this.mode, email)
        // let to, subject, body
        // if (this.mode === 're') {
        //   to = email.from
        //   subject = 'Re: ' + email.subject
        //   body = `\n\nOn ${email.savedAt}, ${email.name} <${email.from}> wrote:\n${email.body}`
        // } else {
        //   to = ''
        //   subject = 'Fwd: ' + email.subject
        //   body = `\n\n---------- Forwarded message ---------\nFrom: ${email.name} <${email.from}>\nDate: ${email.savedAt}\nSubject: ${email.subject}\nTo: <${email.to}>\n\n${email.body}`
        // }
        // this.email = {
        //   to, subject, body
        // }
        if (this.quill) {
          // Set the Quill editor content with the new body
          this.quill.root.innerHTML = this.email.body;
          console.log(this.quill);
        }
      }
      else {
       // this.email = JSON.parse(JSON.stringify(email))
        this.title = email.subject || 'New Message'
      }
      this.buildForm();
      //if (this.mode) this.save(false, false, true)
    })
    this.getClaims();
  }

  buildForm() {
    this.composeForm = this.fb.group({
      to: [this.email.to, [Validators.required], []],
      emailInput: ['', [Validators.required, Validators.email]],  // Form control for 'to' input
      ccInput: ['', [Validators.email]],
      subject: [this.email.subject, [Validators.required], []],
      body: ['', [Validators.required]]
    })
  }

  buildRefEmail(mode: string, email: Email): Email {
    return email;
  }

  autoDrafts() {
    if (this.draftInterval) return
    this.draftInterval = window.setInterval(() => this.save(false, false), 1000000)
  }

  close() {
    this.updateUrl()
  }

  updateUrl(id?: string) {
    this.router.navigate(
      [],
      {
        relativeTo: this.route,
        queryParams: id ? { compose: id } : {},
      })
  }

  save(isSend =true, isClose = true, isFirst = false) {
    console.log("1"+isSend)
    if (isSend && Object.values(this.composeForm.controls).some(v => v.status === 'INVALID'))
      return
    if (!isSend
      && !isFirst
      && this.email.to === this.composeForm.value.to
      && this.email.subject === this.criticalLabel?this.criticalLabel+","+this.claim+","+this.composeForm.value.subject:this.claim+","+this.composeForm.value.subject
      && this.email.body === this.composeForm.value.body)
      return isClose ? this.close() : null
      console.log(isSend)
    this.title = 'Draft saving...'
    this.store.dispatch(new SaveEmail(
      {
        ...this.email,
        ...this.composeForm.value,
        tabs: isSend ? ['sent'] : ['drafts']
      }
    ))
    console.log(2,isSend)
    
    

    if (!this.email._id) {
      this.actions$.pipe(ofType(ADDED_EMAIL)).subscribe(({ email }: any) => {
        if (isSend) {
          this.filterBy$.pipe(take(1)).subscribe(filterBy => {
            this.store.dispatch(new LoadEmails({ ...filterBy }))
          })
        }
        else if (this.route.snapshot.queryParams['compose']) {
          this.email = { ...email, ...this.composeForm.value }
          this.updateUrl(email._id)
          this.title = 'Draft saved'
          setTimeout(() => this.title = email.subject || 'New Message', 15000)
        }
      })
    }
    else {

      this.actions$.pipe(ofType(UPDATED_EMAIL)).subscribe(({ email }: any) => {
        if (isSend) {
          this.filterBy$.pipe(take(1)).subscribe(filterBy => {
            this.store.dispatch(new LoadEmails({ ...filterBy }))
          })
        }
        else {
          this.email = { ...email, ...this.composeForm.value }
          setTimeout(() => this.title = email.subject || 'New Message', 15000)
        }
      })
    }
    if (isClose) this.close()
  }

  public send() {
    console.log("Send button clicked!");
    
    const attachmentsBase64: any[] = [];
    const attachmentFileNames: any[] = [];
  
    const filePromises = this.attachments.map(file => this.convertFileToBase64(file));
    //const bodyTextEncoded = btoa(unescape(encodeURIComponent(this.composeForm.value.body))); 
    
    Promise.all(filePromises).then(base64Files => {
      base64Files.forEach((base64, index) => {
        attachmentsBase64.push(base64.split(',')[1]);
        attachmentFileNames.push(this.attachments[index].name); // Attach the file names
      });
  
      const emailData :any= {
        fromEmail:sessionStorage.getItem('emailAddress')!,
        toEmail: this.recipients,
        ccEmail: this.cc,
        subject: this.critical?this.criticalLabel+","+this.claim+" "+this.composeForm.value.subject:this.claim+" "+this.composeForm.value.subject,
        bodyText: this.composeForm.value.body,
        attachments: [],
      };
  
      for (let i = 0; i < attachmentFileNames.length; i++) {
        emailData.attachments.push({
          fileName: attachmentFileNames[i],
          base64Data: attachmentsBase64[i],
        });
      }
  
      this.emailsService.sendEmail(emailData).subscribe(
        (response) => {
          console.log('Email sent successfully!', response);

         const cachedEmails = JSON.parse(localStorage.getItem(EMAIL_KEY) || '[]');
        cachedEmails.push(emailData);  // Add the new email to the cached list

       
        localStorage.setItem(EMAIL_KEY, JSON.stringify(cachedEmails));

  
        this.store.dispatch(new LoadEmails());
          this.clearCompose();

        },
        (error) => {
        console.error('Error sending email', error);
        this.clearCompose();
          
        }
      );
    }).catch(error => {
      console.error("Error in file conversion:", error);
    });
  }
  
  clearCompose() {
    // Reset the form fields
    this.composeForm.reset();
    
    // Clear the Quill editor content
    if (this.quill) {
      this.quill.root.innerHTML = ''; // Clear the editor content
    }
  
    // Clear the recipients, cc, and attachments
    this.recipients = [];
    this.cc = [];
    this.attachments = [];
  
    // Clear other related variables
    this.emailInput = '';
    this.ccInput = '';
    this.emailSuggestions = [];
    this.showPopup = false;
    this.isTablePopupOpen = false;
  
    // Optionally, reset the title if needed
    this.title = 'New Message';
    this.router.navigate(["email/inbox"]);
  }

  convertFileToBase64(file: any): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file instanceof File) { // Ensure it's an instance of File
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => reject('Error reading file');
      reader.readAsDataURL(file);

    }  else if (file && file.url) {
      // Fetch the claim file and convert to Base64
      fetch(file.url)
        .then(response => response.blob())  // Get the file as a Blob
        .then(blob => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = () => reject('Error reading claim file');
          reader.readAsDataURL(blob);  // Convert Blob to Base64
        })
        .catch(error => reject(`Error fetching claim file: ${error}`));
    } else {
      reject('Selected item is not a file');
    }
  });
}

  
  ngOnDestroy() {
    this.subscription?.unsubscribe()
    if (this.draftInterval) clearInterval(this.draftInterval)
  }

  onFileSelect(event: any) {
    const files = event.target.files;
    if (files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        this.attachments.push(files[i]);
      }
    }
  }

  removeAttachment(index: number) {
    this.attachments.splice(index, 1);
  }

  openTablePopup() {
    this.isTablePopupOpen = true;
  }

  closeTablePopup() {
    this.isTablePopupOpen = false;
  }

  selectFile(file: File) {
    this.attachments.push(file);
    this.closeTablePopup();
  }
  getClaims() {
    this.claims = [
      {
        docId:1,
        claimId: '2000076582-1',
        policyType: 'Commercial Auto',
        description: 'BW - CLAIMANT DENIAL',
        files: { name: 'Claimant Denial', type: 'application/pdf', url: 'assets/files/document1.pdf' }
      },
      {
        claimId: '2000148044-1',
        policyType: 'Personal Auto',
        description: 'New Claim Notification',
        files: { name: 'Claim Notifiation', type: 'application/pdf', url: 'assets/files/document1.pdf' }
      },
      {
        claimId: '2000078081-1',
        policyType: 'Homeowners',
        description: 'Agent Notification Email',
        files: { name: 'Agent Notification', type: 'application/pdf', url: 'assets/files/document1.pdf' }
      },
      {
        claimId: '2000076582-1',
        policyType: 'Commercial Auto',
        description: 'BW - CLAIMANT DENIAL',
        files: { name: 'Claimant Denial', type: 'application/pdf', url: 'assets/files/document1.pdf' }
      },
      {
        claimId: '2000148044-1',
        policyType: 'Personal Auto',
        description: 'New Claim Notification',
        files: { name: 'Claim Notifiation', type: 'application/pdf', url: 'assets/files/document1.pdf' }
      },
      {
        claimId: '2000078081-1',
        policyType: 'Homeowners',
        description: 'Agent Notification Email',
        files: { name: 'Agent Notification', type: 'application/pdf', url: 'assets/files/document1.pdf' }
      },
    ];
  }

  onEmailInput(event: any, type: string): void {
    const inputValue = event.target.value.trim();

    this.activeField = type;

    if (type === 'to') {
      this.emailInput = inputValue;
      if (this.emailInput.length > 0) {
        this.showSuggestions(this.emailInput, 'to');
      } else {
        this.emailSuggestions = [];
      }
    } else if (type === 'cc') {
      this.ccInput = inputValue;
      if (this.ccInput.length > 0) {
        this.showSuggestions(this.ccInput, 'cc');
      } else {
        this.emailSuggestions = [];
      }
    }
  }

  // Show suggestions based on input value
  showSuggestions(inputValue: string, type: string): void {
    if (inputValue.length > 0) {
      this.emailSuggestions = this.allEmails.filter(email =>
        email.email.toLowerCase().includes(inputValue.toLowerCase())
      );
      this.showPopup = true;  // Show the popup when there are suggestions
    } else {
      this.emailSuggestions = [];
      this.showPopup = false;  // Hide the popup when there are no suggestions
    }
  }

  // Add email to either "To" or "CC" list based on active field
  addEmail(email: string, type: string): void {
    if (this.isValidEmail(email)) {
      if (type === 'to' && !this.recipients.includes(email)) {
        this.recipients.push(email);
        this.composeForm.controls['emailInput'].setValue('');
        this.emailInput = '';
      } else if (type === 'cc' && !this.cc.includes(email)) {
        this.cc.push(email);
        this.composeForm.controls['ccInput'].setValue('');
        this.ccInput = '';
      }
      this.emailSuggestions = [];
      this.showPopup = false;  // Hide the popup after selecting an email
      this.cdr.detectChanges();
    }
  }

  // Close the popup overlay
  closePopup(): void {
    this.showPopup = false;
    this.emailSuggestions = [];
  }

  removeEmail(index: number, type: string): void {
    if (type === 'to') {
      this.recipients.splice(index, 1);
      if (this.recipients.length === 0) {
        this.composeForm.controls['emailInput'].setValue('');
        this.emailInput = '';
      }
    } else if (type === 'cc') {
      this.cc.splice(index, 1);
      if (this.cc.length === 0) {
        this.composeForm.controls['ccInput'].setValue('');
        this.ccInput = '';
      }
    }
  }
  // Validate email using regex
  isValidEmail(email: string): boolean {
    const regex  = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return regex.test(email);
  }


  viewAttachment(file: any) {
    const fileType = file.type.split('/')[0];
    if (file && file.url) {
      this.currentAttachmentUrl = this.sanitizer.bypassSecurityTrustResourceUrl(file.url);
      if (file.type === 'application/pdf')
        window.open(file.url as string, '_blank');
    }
    else {
      const fileUrl = URL.createObjectURL(file);
      this.currentAttachmentUrl = this.sanitizer.bypassSecurityTrustResourceUrl(fileUrl);
      if (file.type === 'application/pdf')
        window.open(fileUrl as string, '_blank');
    }

    if (fileType === 'image') {
      this.isImageViewer = true;
      this.isPdfViewer = false;
      this.isViewerOpen = true;
    } else if (file.type === 'application/pdf') {
      this.isPdfViewer = true;
      this.isImageViewer = false;
    } else {
      this.isImageViewer = false;
      this.isPdfViewer = false;
      const link = document.createElement('a');
      link.href = file.url || URL.createObjectURL(file);
      link.download = file.name || 'download'; 
      link.click();
    }

  }

  // Method to close the viewer
  closeViewer() {
    this.isViewerOpen = false;
    this.isImageViewer = false;
    this.isPdfViewer = false;
  }
  critical = false;

  clickImp() {
    this.critical = !this.critical;
  }

  isForward:boolean=true;
  forwardClicked(){
    this.isForward=!this.isForward;
  }
}