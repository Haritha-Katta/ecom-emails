import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA, Injector, NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
 
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
 
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
 
import { reducers, metaReducers } from './store/store';
import { AppEffects } from './store/app.effects';
 
import { AppComponent } from './app-root/index';
import { HomeComponent } from './pages/home/home.component';
import { EmailAppComponent } from './pages/email-app/email-app.component';
 
import { AppHeaderComponent } from './cmps/app-header/app-header.component';
 
 
import { EmailDetailsComponent } from './pages/email-details/email-details.component';
import { EmailPreviewComponent } from './cmps/email-preview/email-preview.component';
import { EmailFilterComponent } from './cmps/email-filter/email-filter.component';
import { FolderListComponent } from './cmps/folder-list/folder-list.component';
import { EmailListComponent } from './pages/email-list/email-list.component';
import { EmailComposeComponent } from './cmps/email-compose/email-compose.component';
import { SearchInputComponent } from './cmps/search-input/search-input.component';
import { HeaderSvgComponent } from './svg-cmps/header-svg/header-svg.component';
import { FolderListSvgComponent } from './svg-cmps/folder-list-svg/folder-list-svg.component';
import { CapitalizePipe } from './pipes/capitalize.pipe';
import { LabelEditComponent } from './cmps/label-edit/label-edit.component';
import { FirstWordPipe } from './pipes/first-word.pipe';
 
import { LabelSelectorComponent } from './cmps/label-selector/label-selector.component';
import { LabelTagComponent } from './cmps/label-tag/label-tag.component';
import { DateFormatPipe } from './pipes/date-format.pipe';
import { DateOrAgoPipe } from './pipes/date-or-ago.pipe';
import { EmailForwardComponent } from './cmps/email-forward/email-forward.component';
import { createCustomElement } from '@angular/elements';
 
 
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AppHeaderComponent,
    EmailAppComponent,
   
    EmailDetailsComponent,
    EmailPreviewComponent,
    EmailFilterComponent,
    FolderListComponent,
    EmailListComponent,
    EmailComposeComponent,
    SearchInputComponent,
    HeaderSvgComponent,
    FolderListSvgComponent,
    CapitalizePipe,
    FirstWordPipe,
    LabelEditComponent,
    LabelSelectorComponent,
    LabelTagComponent,
    DateFormatPipe,
    DateOrAgoPipe,
    EmailForwardComponent,
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    StoreModule.forRoot(reducers, {
      metaReducers,
      runtimeChecks: {
        strictStateImmutability: true,
        strictActionImmutability: true,
      },
    }),
    StoreDevtoolsModule.instrument({
      maxAge: 25,
      logOnly: environment.production,
    }),
    EffectsModule.forRoot([AppEffects]),
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {
  constructor(private injector: Injector) {
    const weatherWidgetElement = createCustomElement(AppComponent, { injector });
    customElements.define('emails-widget', weatherWidgetElement);
  }
 
  ngDoBootstrap() {
    // Ensure we define the element only once
    //this.registerCustomElements();
  }
 
  // private registerCustomElements() {
 
   
  //   // Define all the components that need to be registered as custom elements
  //   const customElementsToRegister = [
  //     { component: EmailListComponent, tagName: 'email-widget' },
  //     // Add other components here
  //     { component: EmailAppComponent, tagName: 'email-app' },
  //     { component: AppHeaderComponent, tagName: 'app-header' },
  //     // ...other components
  //   ];
 
  //   customElementsToRegister.forEach(({ component, tagName }) => {
  //     // Register each component as a custom element if it isn't already defined
  //     if (!customElements.get(tagName)) {
  //       const element = createCustomElement(component, { injector: this.injector });
  //       customElements.define(tagName, element);
  //     }
  //   });
  // }
}
 
 